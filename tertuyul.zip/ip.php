<?php

// Fonction pour vérifier la connectivité via le proxy
function checkProxy($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_PROXY, getenv('HTTP_PROXY'));
    curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'e4534da66b6e44a65636:abd75f89d41f804e'); // Remplace par tes identifiants si nécessaire

    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        echo 'Erreur cURL : ' . curl_error($ch) . "\n";
        curl_close($ch);
        exit(1);
    }

    curl_close($ch);
    return json_decode($response, true);
}

// URL d'un service d'API pour tester la connexion
$url = 'https://api.ipify.org?format=json'; // Exemple pour obtenir l'IP

$data = checkProxy($url);

if ($data && isset($data['ip'])) {
    echo "IP: " . $data['ip'] . "\n";
} else {
    echo "Impossible de récupérer l'IP.\n";
}
?>
